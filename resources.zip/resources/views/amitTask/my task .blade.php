my task 22 

1.instalatin laravel
2.composer instalation && laravel version 
3.target class controller does not exist.
4.could not find package laravel with version 7.0 instalable using version php version

*Update php  version upgrade or downgrade

1. get xampp htdoc  backup all data in xampp file
2.rename appche name && i gave name old_apachi
3.rename php file name && i gave name old_php
4.download php 7.4.9 version && install && extract 
6. and latest php version add in xampp php & apche


23-03-2022 

1.Understanding of project 10:00

2.findding template
3.download template && extract
4 project points

1

25-03-2022

1.get backup in htdocs 10 to 1 = 3
2.find xamm in internet 1 to 2 = 1
3. find some issue && solve  2:30 to 3 = 30min
4. xampp  uninstall   $$ installation 3 to 5 = 2
5.and testing php && composer && xampp phpMyadmin
6.laravel download && create test registration task





25-03-2022


only work Understanding of project


28-03-2022 monday

1.discuss project && project flow 11 t 2
2.laravel integretated matrimony website
3.search background images 
4.apply images for home page


29-03-2022 monday

1.best quality finding images
2.same error issues && slove
3. try to set images
4.add cdn in project
5.images set 
6.create  success stories slider 
7.



29-03-2022 

1.fnd best web template 
2. changess code
3.error 
3.create fielter form testing
5.cdn issue not working properly

31-03-2022

1.Search hd images download 
2.create slider in mulltiple
3.create disign
4.add image mouseenter disign
5.compare disign in other project
6.add cdn link
7.

4-04-2022 
1.improving design in index dashboard
2.chenging background images in head
3.add css property
3.search quality images && login registreation form
4. add project information using animation 


5-04-2022 

1.search registration template 
2.try to create login registration page
3.add mulltiple css code

4.add registration logo
5.add validation in signup & login 
6.work static header disign 



5-04-2022 

	1.set images website
	2.search templates
	3.create registration & login  form 
	4.add validation front & backend
	5.testing validation 
	6.add css code & link for disign
	7.show alert error msg
	8.insert data in database
	9.login error solve

8-04-2022 

1.create mail file & send msg dynamic in project
2.add field send email in bride & groom  dynamic
3.logic Controller & error issue
4.create user table using migration 
5.create groom_tbl table using migration 
6.create bride table using migration 
7.testing validation back & front


8-04-2022 

1.create for registration dynamic dropdown
 in user select son,doughter 

2. when useer select son , doughter dynamic change gender set 
3.dropdown using ajax ,jequery & (logic)
4.create admin Dashboard 
5.add cdn admin dashboard
6.search admin dashboard template & download & extract in project


Php Setup

1.uninstall xampp 10 & install xampp 7.4.8 in pc 
2.uninstall php 10 & in install 7.4.9 
3.create php path & save

4.install laravel composer 




12-04-2022 

1.create admin dashboard
2.cdn integration in dashboard
3.include header & footer
4.create for registration dynamic dropdown
5.create all table using migration
6.different header & footer
7.super admin can with out registration login in admin_dashboard && web_dashboard
8.header chenging & condition(logic) & controller logic
9



13-04-2022 

1.testing registration & login & validation & redirect other_page
2.get current url name & set bride_groom pages & convert first words cpapital & remove ('-')

3.create delete button in add_bride_groom_tbl
4.





15-04-2022

1.create dumy groom_profile table in database
2.create filter form in web index blade 
3.search && condition (logic)
4.make a new bride_groom match table 
5.add fields
6.search condition 
7.add css propert & set input field
8.when  search bride & groom filter click find button redirect filter page 
9.filter page make  (match_profile) without route save file in web_landing page 
10.click view  profile in filter pannel show bride _groom all details in view_profile (dumy)
11.add service provider images in view profile 
12.testing && costomise project





16-04-2022


1.

1.create marital_status table  && form using migration (back & front)
2.make model & controller
3.create states table  && form using migration (back & front)

4.create religion table  && form using migration (back & front)
5.add date picker in crete profile(webPannel)
6.when bride & groom create self profile so get state_tbl data 
		birth_state_tbl_id & current_state_tbl_id same data but differnt only name change
	 
7. bride_groom profile get data from marital_status tbl data he use both tbl serch_filter_box && bride_groom profile  

8.add condition bride or groom for direction bride tbl bride role:3 & rolr grm 3
9.create state table  && form using migration (back & front)
10.create bride_groom profile table  && form using migration (back & front)
11.create bride_profile  table  && form using migration (back & front)
11.create groom_profile  table  && form using migration (back & front)

12.change controller & model name in project


18-04-2022
	*webPannel
	1.add cdn * solve error Override cdn 
	2.insert profile in controller database
	3.add link self Profile view in headder
	4.add to column bride_profile_id & reg_bride_tbl_id in three tbl
	5.gave the  random_id for bride & groom 
	6.add condition check randomId && get bride_groom data
	7.create view table & add fields
	8.cutomise code
	



//master .blade .php

18-04-2022

1.testing login & registration & self profile
2.with out crete self_profile you can't view self profile (condition) 
3.hide error msg in two side first index page & self_profile 
4.Trying to get property 'role' of non-object when start project local host:8000(error) solve && condition
5.add dynamic state , marital_status dropdown in search_filter_tbl
6.make  bride groom matches_profile view
7.when bride_groom search data if before  data store database show  else dumy data show 
8.both condition bride & groom same & logic
9. create design & show bride_groom name Details
10.add middleware in admin route middleware 
12.add field column in database 
13.make middleware condition 
14.make bride groom logout 
15.check bride & groom login using  auth 




<!-- imp tommorow task check migration tabls column && all table -->
2.add columns fields migration

being deeply loved by someone gives you strength while loving someone  deeply gives you corage


add fields column in self_profile

====beauty========
1.Complexion youre fairness  (rang)
==========health=====
2.Weight 
3.Height 
4.Physical Statu
5.age 


============20-04-2022===============
1.add column fields in create profile 
2.find hd images 
3.find (search)new year picker & make year picker in profile create
5.search  asset && add assets
6.remove all database table using migration 
7.add field in inser record (controller)
8.add field in inser record (migration tbl)
9.and migrate all record in database table
10.testing 
11.customise code 
12.field data in database 


============21-04-2022===============

1.add bride_groom status && bride_groom in field list
2.dynamic show registration_from && filterbox && create_profile
3.check condition && validation && add valildation && customise  code
4.search time picker && add time picker in self_profile
5.add cdn && search 
6.setup code && solve (error)




============22-04-2022===============
1.right side  myprofile in index  without login and without create self_profile  
			you can't directly access this page and condition bride_groom controller 
2.click filter box show FilterBrideGroom matchesProfileView
3.add link bride_groom profile_Details when click profile_Details show bride_gromm all details
4.check column name
5.create registration for add name 
6. mulltiple joinig table
7.cross check id's
8.(error) when click profile details sho error 

9.add link bride_groom profile_Details when click profile_Details show bride_groom all details pass multiple Parameters check condition get BrideData && GroomData && role check
10 .search user last time login but not sort ouy ...


============23-04-2022===============

1.add condition if already create profile from Bride && Groom show alert msg create profile alredy taken..

2.searching auth event lost login  (pennding)
3.crete recently_view table using migration 
4.create table  recently_view in frontent using multiple joinig
5.mulltiple joinig && condition table
6.when click my_profile save data in database & all get id & role send profile details 
7.

============25-04-2022===============
1.Title name change show title name & chenge field name 1vivah.com
2.show alert msg registration succefully in login page
3.when user field date of birth set age in age field list 
4.when bride login and find groom & show all filter details click all prfile details 
5.click all profile details save data (login user id & roll && visited bride_gromm id & roll)in  database 
6.mulltiple join in controller (logic) && error
7.create view recently view my profile 
8.testing 
9 inser image path & add profile view



============26-04-2022===============

1.changes joinig table & select data
2.solve error issue undefine tables & column in recently view
3.insert identy_proof files
4 create update profile form
5.add upload images in profile view 
6.add css disign 
7.insert profile_image in database using migration
8. customise code 
9. create update modal add value 




============27-04-2022===============
1.create update profile from & add field (task)  
2. upload images testing in view_profile && update bride_froom image profile update 
		& add_image path & save image folder or database 
3.new update image before check condition if data available remove first image & update new img

4.update image & data bride_profile_tbl && groom_profile_tbl && condition
5.update depended bride_groom name in other table   		 
6.add multiple images  testing slider in view_bride_groom_profile
7. joinig tablse && add column in bride_groom_tbl  &&  uploade_images 
8. customise code 
task imp 

add create by :name in bride_groom details & self _profile

current state add crete from & table





============28-04-2022===============

1.add ajax code when user upload image redirect controller
 & return msg show blade(uplode_images)

2.ajax error problum && solve
3.create image_gallry bride_groom can destroy img
4.create route && add destroy link  

5.pass parameter id's in bride _groom_details
6.add condition get data in database & show bride_groom image
7.create slider original image profile && mulltiple
 image profile show in slider  
8.costimise all code add comments

============29-04-2022===============
1.make condition without fill filter box click submit button show alert message
2.mulltiple where condition add
3.create proposal_request button when bride groom click proposal button show who proposed_by_groom view show
3. create migration table & &database & insert 
4.error join tabls 
5.cutomise tables code
6.add field name && changes migrations tabls column
7.controller logic && search error 
9.mulltiple where condition 






============30-04-2022===============

1.when click proposal request show cancel request button
2.create ajax dynamic data send
3.when submit data show alert msg in filter mactches
4.error solve redirect post method  && search error
5.return redirect with msg & id using ajax return 
6.ajax condition 
7.create button proposalRequestCancel && proposalRequest
8.when proposalRequest button click add proposal bride_groom
9.when proposalCancelRequest button click  bride_groom cancel && database

10 . proposalCancelRequest click call ajax function && controller return data && id && msg && condition
11.


============02-05-2022===============

1.remove all tables from database using migration && migrate
2.dynamic hardcode  create superadmin email password in database
3. testing login && registration
4. self_profile table many time reload  error(error)
5. self_profile table sovle many time error 
6.add fill data from state,religion, status
7. change table name  in database tbl  && joinig tabls using migration
8.create model using migration && change code 
9.when bride_groom not upload image show alert msg
10.debugging all project(error)





============03-05-2022===============
1.testing redirects route 
2.add column profile_status in database using migration
3.get data using joinig
4.create button proposal_request && cancel request
5.calling ajax return back condition 
6.when user click  proposal_request button send request bride_groom
	&& show  cancel request button && remive request for bride _groom
7.testing proposal button 3 browsers problem && 

8.balde condition 

9.error handling in exam.com 

============04-05-2022===============
1.testing redirects route 
2.add column profile_status in database using migration
3.get data using joinig
4.create button proposal_request && cancel request
5.calling ajax return back condition condition chack && add 
6.porposal button issue
7.cancel request && testing 


============10-05-2022===============
1.testing proposal requets
2.mulltiple condition try 
3.make buttons
4.add left join 
5.create proposal request view 
6.show request bride && groom
7.pendding proposal request (same issue problem)
8.create dynamic email  send bride groom registration msg
9.create dynamic email  send proposa request in bride groom  details senf msg
10.joinig && migration & condition


============11-05-2022===============
1.solve issue proposal request send email msg bride_groom
2.careate contact form add field
3.add validation front end & back end
4.descuss inquiry for admin mail thro...
5.insert data
7.try image resize && condition
8.find error solution && search resize condition 
9.set image height && width
10.other issues 

============12-05-2022===============
1.find resize image $$ setting && try && error
2.solve error problem
3.set resize image && changes code config/app.php /providers /aliases
4.bride_groom_details set resize image height width
5.update my profile set resize image 

6.when update new  image remove old image from folder
7.remove  image before remove folder img && database  in destroy gallery  
8.customise code  
9.error automatic double img show solve error


============13-05-2022===============
1.add url image path in self profile && destroy image_gallery
2.create bride registration view	in super_admin pannel
3.create groom registration view	in super_admin pannel
4.table headding add add dark black color in all table 
5.create super admin profile 
6.creting migration create table 
7.create model && field
9.add image && show image in admin profile 


============14-05-2022===============
1.upload image in super admin index page 
2.image size height width set 
3.create update profile super admin && name && surname
4.delete old image database && folder 
5.create registration table bride && groom
6.create search bar bride_registration table && groom_registration
7.create  logout model in super admin pannel 
8.add logout link && logout admin redirect login page 
9.create  logout model in web  pannel redirect login page 
10.testing code && logic



============16-05-2022===============
1.add  like oprater condition use in bride_groom fillter box
2. execute code 
3.add condition 
4.search back button && add back button in matches profile
5. add add back button in all view matches profile

6.testing code in Exam.com 
7.counting error problem && slove countion problem 
8.insert problem testing Debugging code step by step
9.slove insert record
10.



============17-05-2022===============

1.testing code in project
2.add validation in profile
3.add mulltiple condition && search
4. unique image store database (conditions)
5.image resizing proper work
6.in array condition && tarnary oprater condition use
7.count image condition only three img accepts store database
8.changess code && add condition 
9.pass parameter id && role
10.create recently view profile bride_groom details

11.other


============18-05-2022===============
1.testing code in project
2.error handle 
3.add  condition create button 
4.when send request proposal  show three buttons accepts btn  && reject btn
4.when click accept button status update 0 . 1
5.when click reject  button cancel request && remove request data  in database
6.


============19-05-2022===============
1.solve issue problem proposel request accepted 
2.show alert msg if proposel request alredy send  
3.add condition where in condition match condition 
4.when click accept proposel request hide proposal request button show alert msg 
5.alert show msg bride side && groom side
6.create proposal request button &&  cancel_request button && accept button 

7.add mulltiple joinig show bride && groom info
8.mulltiple condition && use where in array
9.create full profile details pass parameter id's
10.create view bride groom details
11.testing button show hide accept reject cancel


============20-05-2022===============
1.error solve  unexpect obj in matches profile 
2.get proposel request matches data in database using left joinig 
3.joinig issue error && not show proposel request details
4. testing buttton debugging code 
5.add left join  && where condition he use 






============21-05-2022===============
1.testing code
2.add buttons
3.create proposal_all_request view 
4.create left joning tables get data from other controller && joinig controller
5.create button proposalReq, incomingReq ,
6.show proposal request view bride groom 
7.show incomming request view bride groom 
8.bride groom show all details 
9.error



============23-05-2022===============
1. incomming request add 2 buttons 1.accept btn && reject btn
2. accept button when bride && groom send proposal or when bride groom aceept proposal req  save data database s && update proposal 
3. when click reject button send proposal bride && groom remove in database

4. create accept view send proposal req  when accept bride groom request
5.create recently view my profile 
6.all bride groom  show details in all blades 

7.distinct he used to return only distinct (different) values.
	in recently view my profile
8.double show double data error problem	

============24-05-2022===============
1.testing code
2.hide buttons
3. incomming request add 2 buttons 1.accept btn && reject btn
4. accept button when bride && groom send proposal or when bride groom aceept proposal 
6.error
5.github install && seting 

6.error



============25-05-2022===============
1.add mulltiple condition && where in use && inarray
2.when sent proposal request for bride groom show button cancel && bride pannel show button reject && accept 
3.when bride accept proposal only show proposal accept button  && groom pannel accept sho w button
4. bride && groom reject proposal request click remove button && remove request database
5.


===============================================================
resize imag echngess

1.Resize Image First Step
	1.config/app.php /providers add this code:

	   Intervention\Image\ImageServiceProvider::class,

	  config/app.php /aliases:
	  	  'Image' => Intervention\Image\Facades\Image::class

2.Resize Image Second  Step

	1.framwork/src/llluminate/database /capsule/manager.php:

			namespace Illuminate\Database\Capsule;
			use Illuminate\Database\Capsule\Manager as DB;

			use Illuminate\Container\Container;
			use Illuminate\Contracts\Events\Dispatcher;
			use Illuminate\Database\Connectors\ConnectionFactory;
			use Illuminate\Database\DatabaseManager;
			use Illuminate\Database\Eloquent\Model as Eloquent;
			use Illuminate\Support\Traits\CapsuleManagerTrait;
			use PDO;

			class Manager
			{
			    use CapsuleManagerTrait;

			    //changes
			    $Capsule = new Capsule;
			    $Capsule->addConnection(config::get('database'));
			    $Capsule->setAsGlobal();  //this is important
			    $Capsule->bootEloquent();


			    *controller

					if($request->hasfile('profile_image')){
					$image  = $request->file('profile_image');
					$filename = $image->getClientOriginalName();


					$width = 190; // your max width
					$height = 270; // your max height
					$image_resize = Image::make($image->getRealPath());              
					$image_resize->resize($width, $height);
					$image_resize->save(public_path('self_profiles/' .$filename));

===============================================================

@if(1 == 1)
	@if(url()->current() === 'http://localhost:8000/super_admin/index')
		<!-- admin Dashboard -->

    	@include('include_admin_dashboard_headers.header')
		@yield('content')
		
		@include('include_admin_dashboard_headers.footer')
	@else
		<!-- admin outher pages Dashboard -->
		@include('include_admin_dashboard_headers.other_header')
		@yield('content')



		@include('include_admin_dashboard_headers.footer')
	@endif
@else
	<!-- web header -->
	@include('include_web_headers.header')
	@yield('content')
	@include('include_web_headers.footer')

@endif




------------------------ bride goroom datadelete--------------------------
  <!--  <td><a href="{{route('destroy_bride_groom',['id'=>$value->id])}}"onclick="return confirm('Are you sure you want to delete this usere?');"><i class='far fa-trash-alt'></i></a></td> -->
---------------------------
service provider registration

1.FirstName,MiddleName,LastName ,Email,Password 
2. how mamy days service create dropdown
3.automatic select price  Ex. 1month = price 500 hundred




my IFSC CODE:  INDB 0000025

ACCOUNT NO. 50 9545969607



Sanket@123
 
AddBrideGroomModel only 2 controllars : 1superAdmin 2.RegistrationController




===============

superadmin@gmail.com 

$2y$10$evsTqnEyvqLd1MFDfYiFC.ZLhTL6TUoIU2xS7cqzx4uRCoj1egmWy

password


INSERT INTO `users` (`id`, `email`, `password`, `show_password`, `reg_groom_tbl_id`, `reg_bride_tbl_id`, `role`, `bride_profile_id`, `groom_profile_id`, `remember_token`, `created_at`, `updated_at`) VALUES ('1', 'superadmin@gmail.com ', '$2y$10$evsTqnEyvqLd1MFDfYiFC.ZLhTL6TUoIU2xS7cqzx4uRCoj1egmWy\r\n', 'password\r\n', NULL, NULL, '1', NULL, NULL, NULL, NULL, NULL);