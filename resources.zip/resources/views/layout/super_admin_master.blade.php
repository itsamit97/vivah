	@include('include_admin_dashboard_headers.header')
	@yield('content')
	@include('include_admin_dashboard_headers.footer')