
	<!-- web header -->
	@include('include_web_headers.header')
	@yield('content')
	@include('include_web_headers.footer')

