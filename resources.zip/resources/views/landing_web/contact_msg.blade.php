<p>Title : {{$data['title']}} </p>
<p>Name Details: {{$data['nameDetails']}}</p>

<p>{{$data['message']}}</p>
