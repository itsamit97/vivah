<p>Title : {{$data['title']}} </p>
<p>Proposal Request: {{$data['message']}}</p>
