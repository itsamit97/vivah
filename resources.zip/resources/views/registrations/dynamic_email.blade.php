<p>Title : {{$data['title']}} </p>
<p>For you: {{$data['message']}}</p>
